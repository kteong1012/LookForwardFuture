EnhancedScroller
echo17 software


http://www.echo17.com



---------------



EnhancedScroller:



Allows you to set up a scroll area that will recycle list items. This saves memory and processing power. The result is most noticeable on lighter platforms such as mobile devices.

Please look through the demo scenes for various ways to configure the scroller. Also, the Tutorials folder contains documentation to walk you through creating a scroller from scratch.





For support information, please navigate to http://www.echo17.com or http://www.echo17.com/forum